window.addEventListener('load', function() {

  var useVR = true

  function gotSourcesHandler( sourceInfos ){
    
    var webcamsElement = document.querySelector( '#webcams' )

    webcams.attachToElement( sourceInfos[ 3 ].id, webcamsElement )

    console.log( sourceInfos )
  }

  // var webcams = new WebcamSources( { gotSourcesCallback: gotSourcesHandler })
  
  // attachLeftCamera()
  
  if ( navigator.getVRDevices ) {
  
      navigator.getVRDevices().then( vrDeviceCallback )
  
  } else if (navigator.mozGetVRDevices) {
  
      navigator.mozGetVRDevices( vrDeviceCallback )
  
  }

}, false )


function attachLeftCamera(){
  $('#backdrop-left').webcam({
    width: 640,
    height: 480,
    swffile: '/swf/jscam_canvas_only.swf',
    onTick: function() {},
    onSave: function() {},
    onCapture: function() {},
    debug: function() {},
    onLoad: function() {
      window.leftCamera = window.webcamx
      window.setTimeout( function(){
        window.webcam.setCamera( 2 ) 
        attachRightCamera() 
      }, 2000 )
    }
  })
}

function attachRightCamera(){
  $('#backdrop-right').webcam({
    width: 640,
    height: 480,
      swffile: '/swf/jscam_canvas_only.swf',
      onTick: function() {},
      onSave: function() {},
      onCapture: function() {},
      debug: function() {},
      onLoad: function() {
        window.setTimeout( function(){
          window.webcam.setCamera( 1 )
        }, 2000 )
        window.rightCamera = window.webcam
        console.log( window.rightCamera.getCameraList(), '2' )

        // if ( useVR ){

          if ( navigator.getVRDevices ) {
          
              navigator.getVRDevices().then( vrDeviceCallback )
          
          } else if (navigator.mozGetVRDevices) {
          
              navigator.mozGetVRDevices( vrDeviceCallback )
          
          }
        
        // }
        // else{

        //   init()

        // }

      }
    })
}

function vrDeviceCallback(vrdevs) {

    for (var i = 0; i < vrdevs.length; ++i) {
        if (vrdevs[i] instanceof HMDVRDevice) {
            vrHMD = vrdevs[i];
            break;
        }
    }
    for (var i = 0; i < vrdevs.length; ++i) {
        if (vrdevs[i] instanceof PositionSensorVRDevice &&
            vrdevs[i].hardwareUnitId == vrHMD.hardwareUnitId) {
            vrHMDSensor = vrdevs[i];
            break;
        }
    }

    init( vrHMD, vrHMDSensor )

}

function init( vrHMD, vrHMDSensor ){

  var sunrise = new Sunrise({
    domElement: document.querySelector( '#main'),
    useVR: true,
    vrHMD: vrHMD,
    vrHMDSensor: vrHMDSensor
  })

}

window.AudioContext = window.AudioContext || window.webkitAudioContext 

window.requestAnimationFrame = (function(){
return window.requestAnimationFrame  ||
  window.webkitRequestAnimationFrame ||
  window.mozRequestAnimationFrame    ||
  window.oRequestAnimationFrame      ||
  window.msRequestAnimationFrame     ||
  function(callback){
  window.setTimeout(callback, 1000 / 60)
}
})()

Math.deg2rad = function( degrees ) {
  return degrees  * ( Math.PI/180)
}

Math.rad2deg = function(radians){
   degrees = 360 * radians/(2 * Math.PI);
   return degrees;
}

Math.distance = function(x, y, x0, y0){
  return Math.sqrt((x -= x0) * x + (y -= y0) * y);
}

