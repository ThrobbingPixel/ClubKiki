
ProximityShader = {

	uniforms: {
		"uPositions": { type: "v3v", value: null },
		"uMagnitudes": { type: "fv1", value: null },
		"uDistanceThreshold": { type: "f", value: 250.0 },
	},

	vertexShader: [

		"uniform vec3 uPositions[ 48 ];",

		"uniform float uMagnitudes[ 48 ];",

		"uniform float uDistanceThreshold;",

		"varying vec2 vUv;",

		"varying vec4 vPosition;",

		"varying float vProximity;",

		"void main() {",

			"vUv = uv;",

			"vPosition =  modelMatrix * vec4( position, 1.0 );",

			"float proximity = 0.0;",

			"vec3 proxPosition = vec3( 0.0, 0.0, 0.0 );",

			"const int PROXIMITY_POSITIONS = 48;",

			"float magnitude = 0.0;",

			"for( int i = 0; i < PROXIMITY_POSITIONS; i++ ){",

				"proxPosition = uPositions[ i ]; magnitude = uMagnitudes[ i ];",
				
				"proximity += sqrt(100.0 * magnitude) * .005 * ( uDistanceThreshold - min( distance( proxPosition.xyz, vPosition.xyz ), uDistanceThreshold ) ) / uDistanceThreshold;",

			"}",

			"vProximity = proximity;",


    	"vec3 newPosition = position + normal * 305.0 * proximity;",
    	"gl_Position = projectionMatrix * modelViewMatrix * vec4( newPosition, 1.0 );",



			// "vec4 pos = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );",

			// "pos.xyz += ( normal * proximity * 50.0);",

			// "gl_Position = pos;",

		"}"

	].join("\n"),

	fragmentShader: [

		"varying vec2 vUv;",

		"varying float vProximity;",

		"void main() {",
 
			"gl_FragColor = vec4( .1 + vProximity, vProximity, vProximity, 1.0 );",
			// "gl_FragColor = vec4( 1.0 );",

		"}"

	].join("\n")

};
