Sunrise = function ( params ){

  this.clock = new THREE.Clock()

  console.log( 'Sunrise', params )

  this.useVR = params.useVR

  this.worldRadius = 500
  this.worldHeight = 400

  if( this.useVR ){

    this.vrHMD = params.vrHMD

    this.vrHMDSensor = params.vrHMDSensor

  }

  this.windowWidth = window.innerWidth
  this.windowHeight = window.innerHeight

  this.init()

}

Sunrise.prototype.render = function(){

  this.controls.update()

  var 
  delta = this.clock.getDelta(),
  state = this.vrHMDSensor.getState(),
  removedUFOs = [],
  _this = this,
  segmentPositions = [],
  segmentMagnitudes = [],
  ids = []



  _.each( this.ufos, function( ufo, id ){    

    if( Math.abs( Math.distance( ufo.body.position.x, ufo.body.position.z, 0, 0 ) ) > ( _this.worldRadius + 100 ) ){
    
      ufo.remove()
      removedUFOs.push( id )
    
    }
    else{

      ids.push( id )
      ufo.update( delta )

    }

  })

  _.each( removedUFOs, function( id ){
    // console.log( 'removing ufo ' + id )
    delete _this.ufos[ id ]

    ufo = _this.addUFO()
    ufo.update( delta )

    ids.push( _this.currentUFOId )
  
  })


  if( ids.length == 3 ){
  
    segmentPositions = segmentPositions.concat( _this.ufos[ ids[ 0 ] ].segmentPositions, _this.ufos[ ids[ 1 ] ].segmentPositions, _this.ufos[ ids[ 2 ] ].segmentPositions )
    segmentMagnitudes = segmentMagnitudes.concat( _this.ufos[ ids[ 0 ] ].segmentMagnitudes, _this.ufos[ ids[ 1 ] ].segmentMagnitudes, _this.ufos[ ids[ 2 ] ].segmentMagnitudes )
  }
  else{
    console.log(ids.length)
  }

  this.proximityMaterial.uniforms.uPositions.value = segmentPositions
  this.proximityMaterial.uniforms.uMagnitudes.value = segmentMagnitudes

  this.camera.quaternion.set( state.orientation.x, 
                        state.orientation.y, 
                        state.orientation.z, 
                        state.orientation.w )


  // ensure object3d.matrixWorld is up to date
  this.camera.updateMatrixWorld()
  // get matrixWorld
  var matrixWorld = this.camera.matrixWorld
  ////////////////////////////////////////////////////////////////////////
  // set position
  var position  = new THREE.Vector3().setFromMatrixPosition(matrixWorld)
  this.audioContext.listener.setPosition(position.x, position.y, position.z)

  ////////////////////////////////////////////////////////////////////////
  // set orientation
  var mOrientation= matrixWorld.clone();
  // zero the translation
  mOrientation.setPosition({x : 0, y: 0, z: 0});
  // Compute Front vector: Multiply the 0,0,1 vector by the world matrix and normalize the result.
  var vFront= new THREE.Vector3(0,0,1);
  vFront.applyMatrix4(mOrientation)
  vFront.normalize();
  // Compute UP vector: Multiply the 0,-1,0 vector by the world matrix and normalize the result.
  var vUp= new THREE.Vector3(0,-1, 0);
  vUp.applyMatrix4(mOrientation)
  vUp.normalize();
  // Set panner orientation
  this.audioContext.listener.setOrientation(vFront.x, vFront.y, vFront.z, vUp.x, vUp.y, vUp.z);

  // this.vrRenderer.render( this.scene, this.camera )
  this.renderer.render(  this.scene, this.camera )


  requestAnimationFrame( this.render.bind( this ) )

}

Sunrise.prototype.init = function() {

  var _this = this

  if( this.useVR ){

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    this.renderer.setSize( 1920, 1080, false )

    // // Configure composer
    // this.composer = new THREE.EffectComposer( this.renderer )
    // this.composer.addPass( new THREE.RenderPass( this.scene, this.camera ) )

    // this.hblur = new THREE.ShaderPass( THREE.HorizontalTiltShiftShader )
    // this.hblur.uniforms[ 'h' ].value = this.bluriness / this.windowHeight
    // this.hblur.uniforms[ 'r' ].value = this.blurRadius
    // if ( this.blur === true) this.composer.addPass( this.hblur )

    // this.vblur = new THREE.ShaderPass( THREE.VerticalTiltShiftShader )
    // this.vblur.uniforms[ 'v' ].value  = this.bluriness / this.windowWidth
    // this.vblur.uniforms[ 'r' ].value = this.blurRadius
    // if ( this.blur === true) this.composer.addPass( this.vblur )

    // if ( this.bloom === true) this.composer.addPass( new THREE.BloomPass( 0.5, 5, 1 ) )
    // var copyPass = new THREE.ShaderPass( THREE.CopyShader )
    // copyPass.renderToScreen = true
    // this.composer.addPass( copyPass )
  
    this.vrRenderer = new THREE.VRRenderer( this.renderer, this.vrHMD )

    document.querySelector( '#main' ).appendChild( this.renderer.domElement )


    window.addEventListener('keypress', function(e) {
      var element = document.querySelector('#main')
      if (e.charCode == 'f'.charCodeAt(0)) {
        if ( element.mozRequestFullScreen ) {
            element.mozRequestFullScreen({
                vrDisplay: _this.vrHMD
            })
        } else if (element.webkitRequestFullscreen ) {
            console.log( _this.renderer.domElement, _this.vrHMD )
           element.webkitRequestFullscreen({
                vrDisplay: _this.vrHMD,
            })
        }
        // _this.renderer.domElement.requestFullScreen({ vrDisplay: _this.vrHMD })
      }
    }, false)
  
  }
  else{

    this.renderer = new THREE.WebGLRenderer()

  }

  this.scene = new THREE.Scene()

  this.camera = new THREE.PerspectiveCamera(45, 1920 / 1080, 5, 5000)
  this.camera.position.set( 0, 5, 300)
  this.camera.updateProjectionMatrix()

  this.controls = new THREE.OrbitControls( this.camera )

  // scene light
  this.pointLight = new THREE.PointLight( 0xffe989 )
  this.pointLight.position.set( 0, 13, 0   )
  this.pointLight.intensity = 5
  this.scene.add( this.pointLight )


  // add monument
  var geometry = new THREE.SphereGeometry( 5, 64, 64 )
  var material = new THREE.MeshBasicMaterial( {color: 0xffff00} )
  this.sphere = new THREE.Mesh( geometry, material )
  // this.scene.add( this.sphere )

  this.createSkyBox()

  this.currentUFOId = -1
  this.ufos = {}

  this.reflectionTexture = THREE.ImageUtils.loadTexture('/images/sunrise.png')
  this.reflectionTexture.mapping = THREE.SphericalReflectionMapping


  this.audioContext = new AudioContext()

  this.gain = this.audioContext.createGain()
  this.gain.connect( this.audioContext.destination )
  // this.gain.gain.value = 0

  this.samples = new SampleMap({
    url: 'media/audio/sample-maps/modular_bleeps_96samples_120_1.wav',
    bpm: 120,
    sampleCount: 6,
    sampleBeatCount: 1,
    audioContext: this.audioContext,
    gain: this.gain,
    loadCompleteCallback: _this.start.bind(_this),
    // errorCallback: sampleLoadErrorHandler
  })


}

Sunrise.prototype.start = function(){

  this.addUFO()
  this.addUFO()
  this.addUFO()

  this.render()
}

Sunrise.prototype.addUFO = function( ){

  var angle = Math.random() * Math.PI * 2

  this.currentUFOId++
  this.ufos[ this.currentUFOId ] = new UFO({
    scene: this.scene,
    texture: this.cubeMap,
    audioContext: this.audioContext,
    samples: this.samples,
    startPosition: new THREE.Vector3( Math.cos( angle ) * this.worldRadius, ( Math.random() * this.worldHeight ) - ( .5 * this.worldHeight ), Math.sin( angle ) * this.worldRadius )
  })

  return this.ufos[ this.currentUFOId ]

}

Sunrise.prototype.createSkyBox = function() {

  var 
  urls = [
    '/images/sunrise-left.png',
    '/images/sunrise-right.png',
    '/images/sunrise-top.png',
    '/images/sunrise-bottom.png',
    '/images/sunrise-bottom.png',
    '/images/sunrise-front.png',
  ],
  skyBoxMaterialArray = []
    
  for (var i = 0; i < 6; i++)
    skyBoxMaterialArray.push( new THREE.MeshBasicMaterial({
      map: THREE.ImageUtils.loadTexture( urls[i] ),
      side: THREE.BackSide
    }))

  this.skyBox = new THREE.Mesh(
    new THREE.BoxGeometry( 300, 300, 300 ), 
    new THREE.MeshFaceMaterial( skyBoxMaterialArray ) 
  )


  // this.skyBox.position.set( 0, 0, 0 )

  // this.scene.add( this.skyBox )

  var geometry = new THREE.SphereGeometry( 200, 200, 200 )
  // var material = new THREE.MeshBasicMaterial( {
  //   map: THREE.ImageUtils.loadTexture('/images/sunrise.png'),
  //   side: THREE.BackSide
  // })
  
  var map = THREE.ImageUtils.loadTexture('/images/sunrise.png')
  this.cubeMap = THREE.ImageUtils.loadTextureCube( [ '/images/sunrise.png','/images/sunrise.png','/images/sunrise.png','/images/sunrise.png','/images/sunrise.png','/images/sunrise.png' ] )



  this.proximityMaterial =
  new THREE.ShaderMaterial({
    vertexShader:   ProximityShader.vertexShader,
    fragmentShader: ProximityShader.fragmentShader,
    uniforms: ProximityShader.uniforms
  })

  this.sphere = new THREE.Mesh( geometry, this.proximityMaterial )
  this.sphere.position.y = -20
  // this.sphere.position.z = -50
  this.sphere.rotation.y = Math.deg2rad( 90 )
  this.scene.add( this.sphere )


  var geometry = new THREE.PlaneGeometry( 1000, 500, 20, 20 )
  var plane = new THREE.Mesh( geometry, this.proximityMaterial )
  plane.rotation.x = Math.deg2rad( 90 )
  plane.rotation.y = Math.deg2rad( 180 )
  plane.position.y = -200
  // this.scene.add( plane )


}